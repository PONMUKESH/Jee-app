
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Dashboard from './app/screens/Dashboard';
import Roadmap from './app/screens/Roadmap';
import BrainGym from './app/screens/BrainGym';
import ErrorLog from './app/screens/ErrorLog';

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator screenOptions={{
        headerShown: false,
        tabBarStyle: { backgroundColor: "#0A0D12" }
      }}>
        <Tab.Screen name="Dashboard" component={Dashboard} />
        <Tab.Screen name="Roadmap" component={Roadmap} />
        <Tab.Screen name="BrainGym" component={BrainGym} />
        <Tab.Screen name="ErrorLog" component={ErrorLog} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
