
import { View, Text } from 'react-native';

export default function Roadmap(){
  return(
    <View style={{flex:1,backgroundColor:"#000",padding:20}}>
      <Text style={{color:"white"}}>Roadmap Phase System</Text>
    </View>
  )
}
