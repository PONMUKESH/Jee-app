
import { View, Text, Button } from 'react-native';
import { useState } from 'react';

export default function BrainGym(){
  const [q, setQ] = useState(generate());

  function generate(){
    let a = Math.floor(Math.random()*100);
    let b = Math.floor(Math.random()*50);
    return {q:`${a} × ${b}`, ans:a*b};
  }

  return(
    <View style={{flex:1,backgroundColor:"#000",padding:20}}>
      <Text style={{color:"white"}}>Mental Math Blitz</Text>
      <Text style={{color:"#F5B942",fontSize:28,marginTop:20}}>{q.q}</Text>
      <Button title="Next" onPress={()=>setQ(generate())}/>
    </View>
  )
}
