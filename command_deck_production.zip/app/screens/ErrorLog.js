
import { View, Text } from 'react-native';

export default function ErrorLog(){
  return(
    <View style={{flex:1,backgroundColor:"#000",padding:20}}>
      <Text style={{color:"white"}}>Error Log (Coming Soon)</Text>
    </View>
  )
}
