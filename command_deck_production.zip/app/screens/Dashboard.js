
import { View, Text } from 'react-native';
import Countdown from '../components/Countdown';
import { calculateBrainScore } from '../utils/brainScore';

export default function Dashboard() {
  const score = calculateBrainScore(30, 10, 5);

  return (
    <View style={{flex:1,backgroundColor:"#000",padding:20}}>
      <Text style={{color:"#F5B942",fontSize:18}}>Goal: IIT Madras CSE</Text>
      <Text style={{color:"#fff"}}>Target Rank: AIR ≤ 60</Text>

      <Countdown />

      <Text style={{color:"#4ADE80",fontSize:22,marginTop:20}}>
        Brain Elasticity Score: {score}
      </Text>
    </View>
  );
}
