
import { useEffect, useState } from 'react';
import { Text } from 'react-native';

export default function Countdown() {
  const target = new Date("2028-05-25");
  const [days, setDays] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      const diff = target - new Date();
      setDays(Math.floor(diff / (1000*60*60*24)));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  return <Text style={{color:"white"}}>{days} Days Left</Text>;
}
