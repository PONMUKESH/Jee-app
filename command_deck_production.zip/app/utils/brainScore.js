
export function calculateBrainScore(q,p,f){
  return q*2 + p*3 + f*5;
}
